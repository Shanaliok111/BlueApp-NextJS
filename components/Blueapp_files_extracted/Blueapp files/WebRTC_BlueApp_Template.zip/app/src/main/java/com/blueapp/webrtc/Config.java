package com.blueapp.webrtc;

public class Config {
    public static final String WEBRTC_APP_ID = "ADD_YOUR_ID_HERE";
}

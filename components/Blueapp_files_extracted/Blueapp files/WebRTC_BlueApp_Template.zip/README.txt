# BlueApp WebRTC Template

Starter Android project template for WebRTC integration.

Add your WebRTC / Firebase keys in:
app/src/main/java/com/blueapp/webrtc/Config.java

Open in Android Studio and build.
